Contact: twitter.com/Tisor93 - youtube.com/Tisor93

Do not redistribute outside gta5-mods without proper permission from the author.

***********************************************************************

I was having a lot of problems with GTA V after updates, because the mods get corrupted and, as I cannot find what files were new to the game at what files were old, I had to reinstall the game, with downloading 60GB which could be a nightmare if Rockstar Servers are not in place.

So I got tired, open up Visual Studio 2017 and developed my own application to check what changes has been made to the folder and delete the files I need.

<b><u>How to use it</u></b>

<i>Important note: You may need to run the program as Administrator, as permissions will be required to Delete Files on the GTA V folder</i>

<b>Step 1: Get your original database generated</b>

If you have just installed your GTA V and the folder is clean, or you want to save your actual folder status, then get ready to generate your own database.

First, select your GTAV root folder. The program will check for GTA5.exe there, so make sure you select the correct one.
Once selected, click on Generate Original DB. You'll be prompted to save the file. Name it the way you want and save it on a safe place (better outside the GTA V folder)

If you don't have the game recently installed and need the Default Database no worries:  I have included it for you on the download file. It is the default installation from Rockstar Installer (Not steam).

<b>Step 2: Lets CLEAN that folder</b>

Ok so you want to delete everything right? Or maybe check how much sh** you have installed? Ok, let's go for it.

Make sure your root folder is correctly selected (yes, again). Click on Load DB and navigate to that file you created before (or some weeks ago) and click Open. The original database will be loaded into the program. Now the COMPARE!!! button is enabled. Click it. You will get the list of changes made to your GTA V folder. Now you can select all, or the ones you want to delete, and hit the Delete button. Make sure you wanna do it, you cannot go back on that operation.

Also I have included a List option so you can export it and maybe send it to a friend, so you can see your file structure for mods or something like that.


<b><u>Final notes</u></b>

As I don't have a lot of free time, the application is very simple. I just wanted to share it as I know there is more people in my situation. The application will work if you do things right. If you want it to fail: it will fail. If you want to make it crash, it will crash.
Maybe I'll be making updates to this later, but this is the very first version.

Also, this application only check for added files: it does not check if default files has been modified. If people wants this done, I'll consider further development.